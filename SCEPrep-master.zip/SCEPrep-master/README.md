# SCEPrep

## Installation

To install the package use 

```r
install.packages(c("Seurat", "Matrix", "RJSONIO"))
devtools::install_github("ctlab/SCEPrep")

```

## Usage

Single-cell explorer requires several files to be present for each dataset:

* `dataset.json` contains description of the datastet.
* `plot_data.json` contains calculated annotations for every cell (like clustering and tSNE coordinates) as well as precalculated annotations (like cluster borders)
* `exp_data.json` contains gene names and cell barcodes in the same order as they appear in expression matrix, as well as number of total UMIs in the cell.
* `data.h5` is an expression (count) matrix. HDF5 allows to store counts effectively: since for the explorer we mostly need to look expression of a gene in the datasets, HDF5 can effectively compress columns of integers.
* `markers.json` json file describing gene expression markers.
* `files` is a directory where you can put any addtional files of choice.

You can use this package to generate `plot_data.json`, `exp_data.json`, `data.h5` and `markers.json` files. Description file `dataset.json`, however, must be created by hand, see example below.

```r
library(SCEPrep)
library(Seurat)
library(Matrix)
library(RJSONIO)

## below we assume that `data` is Seurat object after running Seurat v3 pipelines.

migrateSeuratObject(data, ".")
migrateMarkers("markers.tsv", c("Cluster"), ".")

## if you had calculated markers for two different resolutions you could use
## migrateMarkers(c("markers_0.6.tsv", "markers_0.8.tsv"), c("resolution_0.6", "resolution_0.8"), ".")


## below is example of how to create description file of public dataset of Human Cell Atlas
write(toJSON(list(
  "public"=T,
  "token"="HCA_hematopoiesis",
  "name"="HCA: Profiling of CD34+ cells from human bone marrow to understand hematopoiesis",
  "description"="Differentiation is among the most fundamental processes in cell biology. Single cell RNA-seq studies have demonstrated that differentiation is a continuous process and in particular cell states are observed to reside on largely continuous spaces. We have developed Palantir, a graph based algorithm to model continuities in cell state transitions and cell fate choices. Modeling differentiation as a Markov chain, Palantir determines probabilities of reaching terminal states from cells in each intermediate state. The entropy of these probabilities represent the differentiation potential of the cell in the corresponding state. Applied to single cell RNA-seq dataset of CD34+ hematopoietic cells from human bone marrows, Palantir accurately identified key events leading up to cell fate commitment. Integration with ATAC-seq data from bulk sorted populations helped identify key regulators that correlate with cell fate specification and commitment.",
  "link"="https://data.humancellatlas.org/explore/projects/091cf39b-01bc-42e5-9437-f419a66c8a45",
  "organism"="Homo sapiens"
)), file.path(".", "dataset.json"))


```
