#' Migrate Seurat object
#'
#' Converts given Seurat object to plot_data.json
#'
#' @param seurat Seurat Object
#' @param outdir outdir
#'
#' @return
#' @export
#' @import Seurat
#' @import Matrix
#' @import rhdf5
#' @import dplyr
#' @import jsonlite
#' @import SeuratWrappers
#' @import velocyto.R
#'
#' @examples
migrateSeuratObject <- function(seurat, outdir, userAnnotations=list()) {

  reductions <- c("FItSNE", "tsne", "umap")
  reductions <- reductions[reductions %in% names(seurat@reductions)]

  if (length(reductions) == 0) {
    stop("No TSNE or UMAP found, please make sure to run some dimensionality reduction first")
  }

  dataForPlot <- as.data.frame(seurat@reductions[[reductions[1]]]@cell.embeddings)

  if (length(reductions) > 1) {
    for (i in 2:length(reductions)) {
      dataForPlot <- cbind(dataForPlot, as.data.frame(seurat@reductions[[reductions[2]]]@cell.embeddings))
    }
  }

  if (length(levels(seurat$orig.ident)) > 1) {
    dataForPlot$Sample <- seurat$orig.ident
  } else {
    samples <- gsub("(\\w+)(_|:)[NATGCx]+", "\\1", colnames(seurat))
    if (length(unique(samples)) > 1 && length(unique(samples)) < 100) {
      dataForPlot$Sample <- as.factor(samples)
    }
  }


  dataForPlot$Cluster <-  Idents(object = seurat)

  umiColumn <- sprintf("nCount_%s", seurat@active.assay)
  geneColumn <- sprintf("nFeature_%s", seurat@active.assay)

  dataForPlot$nUmi <- seurat@meta.data[, umiColumn]
  dataForPlot$nGene <- seurat@meta.data[, geneColumn]
  dataForPlot$nUmiLog2 <- log2(dataForPlot$nUmi)
  dataForPlot$nGeneLog2 <- log2(dataForPlot$nGene)

  clusterColnames <- grep("^(C|c)luster", colnames(dataForPlot), value = T)

  for (clusterColumn in clusterColnames) {
    dataForPlot[, clusterColumn] <- as.factor(dataForPlot[, clusterColumn])
  }

  for (userAnnotation in userAnnotations) {
    dataForPlot <- cbind(dataForPlot, userAnnotation[rownames(dataForPlot), ])
  }

  fields <- list()

  for (column in colnames(dataForPlot)) {
    thisColumn <- dataForPlot[, column]
    if (is.numeric(thisColumn)) {
      fields[[column]] = list(
        type=unbox("numeric"),
        range=c(min(thisColumn), max(thisColumn))
      )
    }
    if (is.factor(thisColumn)) {
      fields[[column]] = list(
        type=unbox("factor"),
        levels=levels(thisColumn)
      )
    }
  }


  annotations <- list()

  for (reduction in reductions) {
    for (clusterCol in clusterColnames) {

      dimColnames <- colnames(seurat@reductions[[reduction]]@cell.embeddings)[1:2]
      summariseSring <- sprintf("%s = median(%s), %s = median(%s)", dimColnames[1], dimColnames[1], dimColnames[2], dimColnames[2])

      centers <- dataForPlot %>%
        dplyr::group_by(!!sym(clusterCol)) %>%
        dplyr::summarize_at(dimColnames, median)
      centers <- as.data.frame(centers)
      centers$Text <- centers[, clusterCol]
      masks <- maskEstimator(dataForPlot, clusterCol, dimColumns = dimColnames)


      centersName = sprintf("%s_%s_centers", reduction, clusterCol)
      bordersName = sprintf("%s_%s_borders", reduction, clusterCol)

      annotations[[centersName]] <- list(
        type=unbox("text"),
        value=unbox(clusterCol),
        coords=dimColnames,
        data=centers
      )

      annotations[[bordersName]] <- list(
        type=unbox("polygon"),
        value=unbox("group"),
        coords=dimColnames,
        data=masks
      )
    }
  }

  rnaVelocity <- Tool(object = seurat, slot = "RunVelocity")

  if (!is.null(rnaVelocity)) {
    for (reduction in reductions) {
      dimColnames <- colnames(seurat@reductions[[reduction]]@cell.embeddings)[1:2]
      details <- show.velocity.on.embedding.cor(emb = Embeddings(object = seurat, reduction = reduction),
                                                rnaVelocity, n = 200, scale = "sqrt",
                                                cex = 0.8, arrow.scale = 3, show.grid.flow = TRUE,
                                                min.grid.cell.mass = 0.5, grid.n = 40, arrow.lwd = 1,
                                                do.par = FALSE, cell.border.alpha = 0.1, return.details = T, n.cores=4)

      annotationName <- sprintf("velocity_%s", reduction)

      garrows <- details$garrows
      data_start <- as.data.frame(garrows[, 1:2])
      colnames(data_start) <- dimColnames
      data_end <- as.data.frame(garrows[, 3:4])
      colnames(data_end) <- dimColnames

      annotations[[annotationName]] <- list(
        type=unbox("arrows"),
        coords=dimColnames,
        data_start=data_start,
        data_end=data_end
      )

    }
  }


  dataset = list(
    fields = fields,
    data = dataForPlot,
    annotations = annotations
  )

  write(toJSON(dataset), file.path(outdir, "plot_data.json"))

  counts <- GetAssayData(seurat, "counts")
  newH5File <- file.path(outdir, "data.h5")

  h5createFile(newH5File)
  h5createGroup(newH5File, "expression")

  h5createDataset(newH5File, "expression/mat", c(nrow(counts), ncol(counts)),
                  storage.mode = "integer", chunk=c(1, ncol(counts)),
                  level=9)

  write(toJSON(list(
    "genes"=rownames(counts),
    "barcodes"=colnames(counts),
    "totalCounts"=colSums(counts)
  )), file.path(outdir, "exp_data.json"))

  chunk_size = 500
  start <- 1
  totalGenes <- nrow(counts)
  while (start <= totalGenes) {
    end <- min(start + chunk_size - 1, totalGenes)
    h5write(as.matrix(counts[start:end, 1:ncol(counts)]),
            newH5File, "expression/mat",
            index=list(start:end,1:ncol(counts)))
    start <- start + chunk_size
  }

  h5closeAll()

  return(file.path(outdir, "plot_data.json"))
}
