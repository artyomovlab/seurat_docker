#' Migrate Markers
#'
#' Convert several tsv table of gene expression markers into single JSON file
#'
#' @param infiles paths to tsv files
#' @param keys json keys for each file
#' @param outdir outdir
#'
#' @return
#' @export
#' @import jsonlite
#'
#' @examples
#' \dontrun{
#' migrateMarkers("./markers.tsv", c("Clustering_0.8"), getwd())
#' }
migrateMarkers <- function(infiles, keys, outdir) {
  totalMarkers <- list()
  for (i in 1:length(infiles)) {
    infile <- infiles[i]
    key <- keys[i]
    markers <- read.table(infile, sep="\t", header=1)
    totalMarkers[[key]] <- markers
  }
  write(toJSON(totalMarkers), file.path(outdir, "markers.json"))
  return(file.path(outdir, "markers.json"))
}
